# 14-Quebra_Estrutural-_e_Bolhas
Quebra estrutural e formação de bolhas
